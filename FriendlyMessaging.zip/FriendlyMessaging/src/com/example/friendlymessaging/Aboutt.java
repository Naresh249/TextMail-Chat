package com.example.friendlymessaging;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;

public class Aboutt extends Activity {

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aboutus);
	}
	
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		// TODO Auto-generated method stub
		 super.onCreateOptionsMenu(menu);
		 MenuInflater blowup=getMenuInflater();
		 blowup.inflate(R.menu.msg_main, menu);
         return true;
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		//return super.onOptionsItemSelected(item);
		switch(item.getItemId())
		{
		case R.id.textmsg:
			Intent obji=new Intent("com.example.friendlymessaging.MAINACTIVITY");
			  startActivity(obji);
			break;
		case R.id.abtus:
			Intent objabt=new Intent("com.example.friendlymessaging.ABOUTT");
			startActivity(objabt);
			break;
		case R.id.email :
			finish();
			Intent objeml=new Intent("com.example.friendlymessaging.EMAIL");
			
			startActivity(objeml);
			break;
			
		case R.id.pref:
			Intent objpref=new Intent("com.example.friendlymessaging.PREFS");
			startActivity(objpref);
			break;
		case R.id.exit :
			finish();
			break;
			
		}
		return true;
	}



	

}
