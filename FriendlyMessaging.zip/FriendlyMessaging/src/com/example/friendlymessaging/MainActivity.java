package com.example.friendlymessaging;

import java.util.ArrayList;
import java.util.Locale;
import com.example.friendlymessaging.R;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.Contacts;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.telephony.SmsManager;


public class MainActivity extends Activity implements OnClickListener  {
	
	Button clearmsg;
	Button searchcontact;
	ToggleButton onoffbutton;
	Button sendmsg;
	Button speakmsg;
	
	EditText contacttextarea;
	EditText msgtextarea;
	TextToSpeech tts;
	
	protected static final int RESULT_SPEECH = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//MediaPlayer startsong=MediaPlayer.create(this,R.raw.krishana);
		//startsong.start();
		
		searchcontact=(Button)findViewById(R.id.searchcontact);
		clearmsg=(Button)findViewById(R.id.clearmsg);
		onoffbutton=(ToggleButton)findViewById(R.id.onoffbutton);
		sendmsg=(Button)findViewById(R.id.sendmsg);
		speakmsg=(Button)findViewById(R.id.speakmsg);
		
		contacttextarea=(EditText)findViewById(R.id.contacttextarea);
		msgtextarea=(EditText)findViewById(R.id.msgtextarea);
		
		clearmsg.setOnClickListener(this);
		searchcontact.setOnClickListener(this);
		onoffbutton.setOnClickListener(this);
		sendmsg.setOnClickListener(this);
		speakmsg.setOnClickListener(this);
		
		
		tts=new TextToSpeech(MainActivity.this,new TextToSpeech.OnInitListener() {
			
			@Override
			public void onInit(int status) {
				// TODO Auto-generated method stub
				if(status!=TextToSpeech.ERROR)
				{
					tts.setLanguage(Locale.US);
				}
				
			}
		});
		
	   
	}
	

	

	
	/* (non-Javadoc)
	 * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
	 */
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		// TODO Auto-generated method stub
		 super.onCreateOptionsMenu(menu);
		 getMenuInflater().inflate(R.menu.msg_main, menu);
         return true;
	}

	




	/* (non-Javadoc)
	 * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		//return super.onOptionsItemSelected(item);
		switch(item.getItemId())
		{
		case R.id.textmsg:
			Intent obji=new Intent("com.example.friendlymessaging.MAINACTIVITY");
			  startActivity(obji);
			break;
		case R.id.abtus:
			Intent objabt=new Intent("com.example.friendlymessaging.ABOUTT");
			startActivity(objabt);
			break;
		case R.id.email :
			finish();
			Intent objeml=new Intent("com.example.friendlymessaging.EMAIL");
			Bundle b1=new Bundle();
			b1.putString("msg_email", msgtextarea.getText().toString());
			objeml.putExtras(b1);
			startActivity(objeml);
			break;
			
		case R.id.pref:
			Intent objpref=new Intent("com.example.friendlymessaging.PREFS");
			startActivity(objpref);
			break;
		case R.id.exit :
			finish();
			break;
			
		}
		return true;
	}





	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		
		case R.id.clearmsg:
		contacttextarea.setText("");
		msgtextarea.setText("");
		    break;
		
		case R.id.onoffbutton :
			if(onoffbutton.isChecked())
			{	
			String input=msgtextarea.getText().toString();
			tts.speak(input, TextToSpeech.QUEUE_FLUSH, null);
			}
			else
				tts.stop();
			break;
			
		
		case R.id.searchcontact :
			@SuppressWarnings("deprecation")
			Intent contactPickerIntent = new Intent(Intent.ACTION_PICK,Contacts.CONTENT_URI);
			startActivityForResult(contactPickerIntent, 2);
			break;
			
		case R.id.sendmsg :
			String phoneNo,msg;
			phoneNo=contacttextarea.getText().toString();
			msg=msgtextarea.getText().toString();
			sendSMS(phoneNo,msg);
			
			break;
		
		case R.id.speakmsg :
			Intent intent = new Intent(
					RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

			intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");
			try
			{
				startActivityForResult(intent,RESULT_SPEECH);
			}
			catch(ActivityNotFoundException a)
			{
				Toast tobj=Toast.makeText(getApplicationContext(),
						"Oops ,your device doesn't support text speech",
						Toast.LENGTH_SHORT);
				tobj.show();
						
			}
			break;
		
		
		}
		
	}





	/* (non-Javadoc)
	 * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		
		switch(requestCode)
		{
		
		
			
		case RESULT_SPEECH: 
			if (resultCode == RESULT_OK && null != data) {

				ArrayList<String> text = data
						.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
				
				msgtextarea.setText(msgtextarea.getText().toString()+" "+text.get(0));
				
			}
			/*else
			{
				msgtextarea.setText("bhai usko sampat nahi padi !");
			}*/
			
			break;
			
		case 3:
			Intent inbx = new Intent("com.example.friendlymessaging.READMSG");
			startActivityForResult(inbx, 3);
			
			break;
		case 2:
		
			
			String phoneNumber="";
			if (resultCode == RESULT_OK && null != data)
			{
				 Uri uri = data.getData();
				 Cursor cursor=getContentResolver().query(uri, null, ContactsContract.Contacts.HAS_PHONE_NUMBER + " = 1", null, null);

				    while (cursor.moveToNext())
				    { 
				    	String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID)); 
				   
				    	Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ contactId,null, null); 
				     
				    	while (phones.moveToNext())
				    	{ 
				    		phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));                 
				    	} 
				    	phones.close();
				    	phoneNumber = phoneNumber.replaceAll("-", "");
				    	phoneNumber = phoneNumber.replaceAll(" ", "");
				    	contacttextarea.setText(phoneNumber);
				    }
				
			}
		break;
		}
	}
	
	// Messaging Sending code
	
	public void sendSMS(String phone,String message)
	{
		String SENT = "SMS_SENT";
	    String DELIVERED = "SMS_DELIVERED";

	    Intent sentIntent = new Intent(SENT);
	    Intent deliveredIntent = new Intent(DELIVERED);
	    PendingIntent sentPI = PendingIntent.getBroadcast(this, 0,sentIntent, 0);        
	    PendingIntent deliveredPI = PendingIntent.getBroadcast(this, 0,deliveredIntent, 0);
	    
	    BroadcastReceiver sentReceiver = new BroadcastReceiver()
	    {
	    	@Override public void onReceive(Context c, Intent in)
	    	{
	    		switch (getResultCode())
	    		{
                case Activity.RESULT_OK:
                    Toast.makeText(getBaseContext(), "SMS sent ",Toast.LENGTH_SHORT).show();
                    msgtextarea.setText("");
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    Toast.makeText(getBaseContext(), "Generic failure",Toast.LENGTH_SHORT).show();
                    break;
                case SmsManager.RESULT_ERROR_NO_SERVICE:
                    Toast.makeText(getBaseContext(), "No service",Toast.LENGTH_SHORT).show();
                    break;
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    Toast.makeText(getBaseContext(), "Null PDU",Toast.LENGTH_SHORT).show();
                    break;
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    Toast.makeText(getBaseContext(), "Radio off",Toast.LENGTH_SHORT).show();
                    break;
	    		}
	    	}
	    };
	    
	    BroadcastReceiver deliverReceiver = new BroadcastReceiver()
	    {
	    	@Override public void onReceive(Context c, Intent in)
	    	{
	    		switch (getResultCode())
	    		{
                case Activity.RESULT_OK:
                    Toast.makeText(getBaseContext(), "SMS delivered", Toast.LENGTH_SHORT).show();
                    break;
                case Activity.RESULT_CANCELED:
                    Toast.makeText(getBaseContext(), "SMS not delivered", Toast.LENGTH_SHORT).show();
                    break;                      
	    		}  
	    	}
	    };
	    
	    SmsManager mysms=SmsManager.getDefault();
	    
	    ArrayList<String> multiSMS = mysms.divideMessage(message);
	    ArrayList<PendingIntent> sentIns = new ArrayList<PendingIntent>();
	    ArrayList<PendingIntent> deliverIns = new ArrayList<PendingIntent>();
	    
	    for(int i=0; i< multiSMS.size(); i++)
	    {
	    sentIns.add(sentPI);
	    deliverIns.add(deliveredPI);
	    }
	    
		try
		{
			registerReceiver(sentReceiver, new IntentFilter(SENT));
	        registerReceiver(deliverReceiver, new IntentFilter(DELIVERED));
			
			mysms.sendMultipartTextMessage(phone, null, multiSMS, sentIns, deliverIns);
			
		} 
		catch (Exception e)
		{				
			Toast.makeText(getApplicationContext(),	"SMS faild, please try again later!",Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
		 ContentValues my_values = new ContentValues();
		  my_values.put("address", phone);
		  my_values.put("body", message);
		  getContentResolver().insert(Uri.parse("content://sms/inbox"), my_values);
	}
}
