package com.example.friendlymessaging;

import java.util.ArrayList;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.speech.RecognizerIntent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.view.View.OnClickListener;

import com.example.friendlymessaging.R;

public class Email extends Activity implements OnClickListener{

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 * 
	 */
	
	Button sendemail;
	ImageButton email_voicebtn;
	EditText email_address,email_subject,email_body;
	String subject,e_msg,e_address,selectedLang;
	protected static final int RESULT_SPEECH = 1;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.email);
		
		sendemail=(Button) findViewById(R.id.sendemail);
		email_voicebtn=(ImageButton) findViewById(R.id.email_voicebtn);
		email_address=(EditText) findViewById(R.id.email_address);
		email_subject=(EditText)findViewById(R.id.email_subject);
		email_body=(EditText) findViewById(R.id.email_body);
		
		sendemail.setOnClickListener(this);
		email_voicebtn.setOnClickListener(this);
		
		SharedPreferences getlang = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
		selectedLang = getlang.getString("select_lang", "1");
		
		Bundle recv1 = getIntent().getExtras();
		email_body.setText(recv1.getString("msg_email"));
	}
	
	
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		// TODO Auto-generated method stub
		 super.onCreateOptionsMenu(menu);
		 MenuInflater blowup=getMenuInflater();
		 blowup.inflate(R.menu.msg_main, menu);
         return true;
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		//return super.onOptionsItemSelected(item);
		switch(item.getItemId())
		{
		case R.id.textmsg:
			Intent obji=new Intent("com.example.friendlymessaging.MAINACTIVITY");
			  startActivity(obji);
			break;
		case R.id.abtus:
			Intent objabt=new Intent("com.example.friendlymessaging.ABOUTT");
			startActivity(objabt);
			break;
		
			
		case R.id.pref:
			Intent objpref=new Intent("com.example.friendlymessaging.PREFS");
			startActivity(objpref);
			break;
		case R.id.exit :
			finish();
			break;
			
		}
		return true;
	}

	
	public void onClick(View v){
		
		switch(v.getId())
		{
		case R.id.email_voicebtn:
			Intent intent = new Intent(
					RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

			intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");

			try 
			{
				startActivityForResult(intent, RESULT_SPEECH);
			} 
			
			catch (ActivityNotFoundException a)
			{
				Toast t = Toast.makeText(getApplicationContext(),
						"Oops! Your device doesn't support Speech to Text",
						Toast.LENGTH_SHORT);
				t.show();
			}
			break;
			
		case R.id.sendemail :
			
			e_address=email_address.getText().toString();
			subject=email_subject.getText().toString();
			e_msg=email_body.getText().toString();
			
			String addressArray[]={e_address};
			
			Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
			emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, addressArray);
			emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject);
			emailIntent.setType("plain/text");
			emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, e_msg);
			
			startActivity(emailIntent);
			
			break;
		
	}

}


	/* (non-Javadoc)
	 * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		
		switch (requestCode) {
		case RESULT_SPEECH: 
			if (resultCode == RESULT_OK && null != data) {

				ArrayList<String> text = data
						.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
				
				email_body.setText(email_body.getText().toString()+" "+text.get(0));
				
			}
			break;

		}
	}
	}
	
	
	

